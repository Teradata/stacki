__doc__ = """Copyright (c) 1996. The Regents of the University of California. All rights reserved.

See %s/Legal.htm for license information.
""" % __path__[0]

from MA_version import version as __version__
from MA_version import version_info as __version_info__
from MA import *
from dtest import test
