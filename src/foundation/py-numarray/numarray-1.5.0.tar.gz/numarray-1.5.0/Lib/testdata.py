# This file exists to supply selftest data to chararray.  It writes out
# the file "tb.fits" in the numarray .pyc directory when it is imported.
import os as _os

__path__ = _os.path.split(__file__)
filename = _os.path.join(__path__[0], "testdata.fits")





