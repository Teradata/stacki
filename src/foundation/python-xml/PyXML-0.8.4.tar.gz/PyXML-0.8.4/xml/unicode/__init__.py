"""This package exists for compatibility with PyXML 0.5.x. Its
functionality is superceded by the Python 2.0 Unicode type; it should
be used only by 4DOM."""
