extensions = ['sphinx.ext.autosummary']

# The suffix of source filenames.
source_suffix = '.rst'
autosummary_generate = True
