
def withSentence():
    '''I have a sentence which
    spans multiple lines. Then I have
    more stuff
    '''
    pass

def noSentence():
    '''this doesn't start with a
    capital. so it's not considered
    a sentence
    '''
    pass

def emptyLine():
    '''This is the real summary

    However, it did't end with a period.
    '''
    pass
