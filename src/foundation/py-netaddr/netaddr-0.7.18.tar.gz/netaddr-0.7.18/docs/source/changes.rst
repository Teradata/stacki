============================
What's new in netaddr 0.7.18
============================

.. include:: ../../CHANGELOG
