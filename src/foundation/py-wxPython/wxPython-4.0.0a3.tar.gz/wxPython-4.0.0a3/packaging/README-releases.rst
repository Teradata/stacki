Auxiliary wxPython Release Files
================================

The source and binary extension modules for wxPython are located at PyPI where
they can be downloaded either manually or automatically via the pip tool.  See
https://pypi.python.org/pypi/wxPython

The files in this folder are the extras that are not uploaded to PyPI,
including the documentation, demo and samples, and also debugger information
files (.pdb) for Visual Studio.

