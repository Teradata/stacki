This folder is where the ouput of SIP is placed. These will be the C++ source
and header files, as well as a file for each module that specifies what files
were generated for that module (which is used by the build scripts.)

Currently these files are not committed to the SVN repository, but
they should be included in any source tarballs that are distributed.
