.. _git-development:

=====================
 Git for development
=====================

Contents:

.. toctree::
   :maxdepth: 2

   development_setup
   configure_git
   development_workflow
